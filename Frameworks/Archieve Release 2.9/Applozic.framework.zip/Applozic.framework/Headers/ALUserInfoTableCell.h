//
//  ALUserInfoTableCell.h
//  Applozic
//
//  Created by devashish on 16/05/2016.
//  Copyright © 2016 applozic Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ALUserInfoTableCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *userValueLabel;
@property (strong, nonatomic) IBOutlet UILabel *userPropertyLabel;

@end
