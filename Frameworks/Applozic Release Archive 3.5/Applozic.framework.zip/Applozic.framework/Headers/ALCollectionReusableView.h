//
//  ALCollectionReusableView.h
//  Applozic
//
//  Created by devashish on 18/04/2016.
//  Copyright © 2016 applozic Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ALCollectionReusableView : UICollectionReusableView

@property (weak, nonatomic) IBOutlet UITextField *msgTextField;

@end
