//
//  NSObject+ApplozicBridge.m
//  applozicswift
//
//  Created by Applozic Inc on 11/25/15.
//  Copyright © 2015 Applozic. All rights reserved.
//

#import "NSObject+ApplozicBridge.h"

@implementation NSObject (ApplozicBridge)

@end
