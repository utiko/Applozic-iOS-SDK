//
//  NSObject+ApplozicBridge.h
//  applozicswift
//
//  Created by Applozic Inc on 11/25/15.
//  Copyright © 2015 Applozic. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (ApplozicBridge)

@end
